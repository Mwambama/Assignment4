package api;

public enum CardinalDirection {
	NORTH, EAST, SOUTH, WEST;
}
