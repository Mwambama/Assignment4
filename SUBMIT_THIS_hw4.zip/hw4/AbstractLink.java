package hw4;

import api.Crossable;
import api.Point;
import api.PositionVector;

/**
 * 
 * @author mwambama
 *
 *abstract link implements Crossable
 *I did the  hierarchy as traversable as parent of crossable
 *crossable the parent of abstract
 *abstract(super class) is the parent of all the other sub-classes(children), 
 *I extended the Multi-switch link class to MultiFixed link
 */
   
public abstract class AbstractLink implements Crossable {
	
	  /**
	   * if the train is in path
	   */
	  private boolean inPath;
	  /**
	   * the end of the first path
	   */
	  private Point endpoint1;
	  /**
	   * the end of the second path
	   */
	  private Point endpoint2;
	  /**
	   * the end of the third path
	   */
	  private Point endpoint3;
	  /**
	   * pointA is given by the point class
	   */
	  private Point pointA;
	  /**
	   * pointB is given by the point class
	   */
	  private Point pointB;
	 
	
	/**
	 * Initializes all the points to null
	 * the path is not currently in uses by a train
	 */
    public  AbstractLink() {
	     
	    inPath = false;
	    endpoint1 = null;
	    endpoint2 = null;
	    endpoint3 = null;
	    
	   
	}
    
    
   /**
    * Gets the point that is connected to the given point.
    * The point to find the connected point for
    * The connected point for the given point, 
    * or null if no connected point is found.
    */
   @Override
   public void shiftPoints(PositionVector positionVector) {
	// TODO Auto-generated method stub
	   
	pointA = getConnectedPoint(positionVector.getPointB());
	   
	if(pointA == pointA.getPath().getHighpoint()) {
		pointB = pointA.getPath().getPointByIndex(pointA.getPath().getNumPoints()-2);
	}
	else if(pointA == pointA.getPath().getLowpoint()) {
		 pointB = pointA.getPath().getPointByIndex(1);
	}
  
    positionVector.setPointB(pointB);
    
    
    positionVector.setPointA(pointA);
    
    
     
	
}
     
   @Override
   public Point getConnectedPoint(Point point) {
	// TODO Auto-generated method stub
	   
	   
	return null;
  }
    
   @Override
   public void trainEnteredCrossing() {
	// TODO Auto-generated method stub
	
   }
      @Override
   public void trainExitedCrossing() {
	// TODO Auto-generated method stub
	
   }
     
      
   @Override
   public int getNumPaths() {
	// TODO Auto-generated method stub
	return 0;
   }
   


}
