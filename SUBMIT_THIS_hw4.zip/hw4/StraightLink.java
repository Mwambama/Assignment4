package hw4;

import api.Point;
import api.PositionVector;
import hw4.AbstractLink;
/**
 * 
 * @author mwambama
 * 
 * represents a straight rail link between three points in a railway system. 
 * straight link extends the AbstractLink class
 */

public class StraightLink extends AbstractLink{
    /**
     * 
     * @param endpointA  A train from A always passes to B
     * @param endpointB  A train from B always passes to A
     * @param endpointC  A train from C always passes to A
     */
	    
	  /**
	   * the first endpoint in the straight link
	   */
	  private Point endpointA;
	  /*
	   * the second endpoint in the straight link
	   */
	  private Point endpointB;
	  /**
	   * the third endpoint in the straight link
	   */
	  private Point endpointC;
	  
	  /*
	   * Initializes the straight link with its three endpoints
	   * 
	   */
	  public StraightLink (Point endpointA,Point endpointB,Point endpointC ) {
		   
		   this.endpointA = endpointA;
		   this.endpointB = endpointB;
		   this.endpointC = endpointC;
		   this.endpointB = endpointB;
		   
	  }
	  
	     /**
	      *  
	      *  Returns the connected point of a given point on the straight link.
	      *  If the given point is equal to endpointA, the method returns endpointB
	      *  If the given point is equal to endpointB, the method returns endpointA
	      *  If the given point is equal to endpointC,the method returns endpointA
	      *  . Otherwise, the method returns null.
	      */
		@Override
		public Point getConnectedPoint(Point point) {
			// TODO Auto-generated method stub
			
			
			if (point == endpointA) {
	            return endpointB;
	        } else if (point == endpointB) {
	            return endpointA;
	        } else if (point == endpointC) {
	            return endpointA;
	        } else {
	            return null;
	        }
			
	    }
			

		@Override
		public void trainEnteredCrossing() {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void trainExitedCrossing() {
			// TODO Auto-generated method stub
			
		}

		@Override
		public int getNumPaths() {
			// TODO Auto-generated method stub
			return 3;
		}
		

}
