package hw4;

import api.Point;
import api.PositionVector;
/**
 * 
 * @author mwambama
 *
 *The SwitchLink class represents a switch link in a railway system 
 *that can allow a train to pass
 *through different endpoints depending on its turn status.
 *switch link extends abstract link
 */
  public class SwitchLink extends AbstractLink {
	
	  /**
	   * the first endpoint in the switch link
	   */
	  private Point endpointA;
	  /*
	   * the second endpoint in the switch link
	   */
	  private Point endpointB;
	  /**
	   * the third endpoint in the switch link
	   */
	  private Point endpointC;
	  /**
	   * turn of the train
	   */
	  private boolean trainTurn;
	  
	
	   /**
	    * endpoints are initialized in the constructor
	    * @param endpointA  the first endpoint in the switch link
	    * @param endpointB  the second endpoint in the switch link
	    * @param endpointC  the third endpoint in the switch link
	    */
	public SwitchLink(Point endpointA, Point endpointB, Point endpointC) {
		
		   this.endpointA = endpointA;
		   this.endpointB = endpointB;
		   this.endpointC = endpointC;
		   this.trainTurn = false;
		
	    }
	/**
	 * Sets the turn status of the switch link
	 * @param turn
	 */
	public void setTurn(boolean turn) {
		

		   
	    trainTurn = turn;
	  } 
		 
		/**
		 * Returns the connected point to the specified point on the switch link 
		 * based on the current turn status.
		 * point the point whose connected point is being requested
		 * return  the connected point to the specified point based on the current turn status,
		 * or null if the specified point is not part of the switch link
		 */
    @Override
      public Point getConnectedPoint(Point point) {
	   // TODO Auto-generated method stub
	
	   
	  if(point ==endpointA && trainTurn) {
		  return endpointC;
		  
	  }else if( point ==endpointA && !trainTurn) {
		  return endpointB;
		  
	  }else if(point == endpointB){
		  
		  return endpointA;
		  
	  }else if(point == endpointC) {
		  return endpointA;
		  
	  }else {
		  return null;
	   }
	  
	
      }

     @Override
     public void trainEnteredCrossing() {
     	// TODO Auto-generated method stub
	
      }

     @Override
     public void trainExitedCrossing() {
	  // TODO Auto-generated method stub
	
      }

     @Override
      public int getNumPaths() {
	// TODO Auto-generated method stub
	return 0;
     }

   }
