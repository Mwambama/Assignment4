package hw4;

import api.Point;
import api.PointPair;
import api.PositionVector;
import hw6.AbstractLink;
/**
 * 
 * @author mwambama
 * 
 *  multiSwitchlink extends multiFixedLink
 *  represent a switch able connection between the railroad
 */
public class MultiSwitchLink extends MultiFixedLink {
    
	/**
	 * an array that shows connection between the pairs of points
	 */
	private PointPair[] connections;
	
    /*
     * creates a new Multi-switch-link
     * connection of pairs of points
     * Multi-switch has similar get.connection method as multi-fixed so used super class to call it in there
     */
	
	public MultiSwitchLink(PointPair[] connections) {

		super(connections);
		this.connections = connections;

	}
	/**
	 * updates connection point pair at given index
	 * Switches point pair to new index
	 * 
	 * @param pointPair
	 * @param index
	 */

	public void switchConnection(PointPair pointPair, int index) {
		connections[index] = pointPair;
	}
}
