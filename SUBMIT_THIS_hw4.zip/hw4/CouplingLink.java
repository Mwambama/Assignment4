package hw4;

import api.Crossable;
import api.Point;
import api.PositionVector;
import hw6.AbstractLink;
/**
 * 
 * @author mwambama
 * 
 *coupling link extends abstract link
 */
public class CouplingLink extends AbstractLink {
	
	 private Point endpoint1;
	 /**
	  * represents the two endpoint of the link
	  */
	 private Point endpoint2;
	 /**
	  * represents the two endpoint of the link
	  */
	 /**
	  * 
	  * @param endpoint1  constructor takes 2 points 
	  * @param endpoint2  initialize the two endpoints of the link
	  */
	
	   public CouplingLink(Point endpoint1,Point endpoint2) {
		this.endpoint1 = endpoint1;
		this.endpoint2 = endpoint2;
		
		
	  }

	/**
	 * Returns the connected point of the given point on the link. 
	 * If the given point is not on the link, returns null.
	 * point the point to find the connected point of
	 */

	@Override
	public Point getConnectedPoint(Point point) {
		// TODO Auto-generated method stub
		     
		   Point nextPointA;
		   if(point == endpoint1) {
			   nextPointA = endpoint2;
			   
		   }
		   else {
			   nextPointA = endpoint1;
		   } 
	         return nextPointA;
	  }
	

	@Override
	public void trainEnteredCrossing() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void trainExitedCrossing() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public int getNumPaths() {
		// TODO Auto-generated method stub
		return 2;
	}
	
	
	

}
