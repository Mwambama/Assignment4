package hw4;

import api.Point;
import api.PointPair;
import api.PositionVector;
import hw4.AbstractLink;
/**
 * 
 * @author mwambama
 *
 *MultiFixed link extends abstract link
 */
public class MultiFixedLink extends AbstractLink {
     
	  private  PointPair[] connections;
	  /**
	   * keeps track of pair of a point
	   */
	  private Point endpoint1;
	  private Point endpoint2;
	  private Point endpoint3;
	  
	  
	/**
	 * creates a new connection
	 * creates a new multiFixedlink
	 * @param connections  is initialized in the constructor
	 */
	 public MultiFixedLink(PointPair[] connections){
		
		   this.connections = connections;


	}
 

      @Override
      public Point getConnectedPoint(Point point) {
	   // TODO Auto-generated method stub
	

	  /**
	   * nextPOintA is set to null
	   * then use the loop to iterate through the connections of the current track
	   * then check if connection matches A or B current connection
	   * if either A or B is matched with nextpointA then it sets the value of each current connection
	   * then train return which means next point the train moves to from given point
	   */
	Point nextPointA = null;
	for(int i = 0; i < connections.length; ++i ) {
		if (point ==this.connections[i].getPointA()) {
			nextPointA = this.connections[i].getPointB();
			
		}
		if(point ==this.connections [i].getPointB()) {
			nextPointA = this.connections[i].getPointA();
		}
	  }
	  return nextPointA;
    }

     @Override
       public void trainEnteredCrossing() {
	    // TODO Auto-generated method stub
	
    }

   @Override
    public void trainExitedCrossing() {
	  // TODO Auto-generated method stub
	
    }

   @Override
   public int getNumPaths() {
	// TODO Auto-generated method stub
	return 0;
   }


 }
