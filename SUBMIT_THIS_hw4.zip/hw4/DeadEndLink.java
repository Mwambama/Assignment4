package hw4;

import api.Point;
import api.PositionVector;
/**
 * 
 * @author mwambama
 *
 *Represents a dead-end link which only has one path and doesn't connect to any other links.
 *deadend link extends abstract link
 */
public class DeadEndLink extends AbstractLink{
	 
	/**
	 * Initializes a new instance of deadend link class with no parameters.
	 */
	public DeadEndLink() {
		
	}  
	@Override
	public void shiftPoints(PositionVector positionVector) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Point getConnectedPoint(Point point) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void trainEnteredCrossing() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void trainExitedCrossing() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public int getNumPaths() {
		// TODO Auto-generated method stub
		return 1;
	}
	
	

}
