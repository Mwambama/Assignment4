package hw4;

import api.Point;
import api.PositionVector;
/**
 * 
 * @author mwambama
 *
 * turn link allows a train to make a turn from one direction to another.
 * turn link Extends the abstract link
 * implements the get.connectedpoint method
 */
public class TurnLink extends AbstractLink{
	  
	/**
	   * the first endpoint in the turn link
	   */
	  private Point endpointA;
	  /*
	   * the second endpoint in the turn link
	   */
	  private Point endpointB;
	  /**
	   * the third endpoint in the turn link
	   */
	  private Point endpointC;
	  
	 
	  /**
	   * endpoints are initialized in the constructor
	   * @param endpointA
	   * @param endpointB
	   * @param endpointC
	   */
	public TurnLink (Point endpointA, Point endpointB, Point endpointC) {
		   this.endpointA = endpointA;
		   this.endpointB = endpointB;
		   this.endpointC = endpointC;
		   this.endpointB = endpointB;
	}
	

	
     /**
      * Returns the point connected to the given point in the turn link.
      * point the point for which to find the connected point
      * then return the connected point, 
      * or null if the given point is not connected to any point in the turn link
      */
	@Override
	public Point getConnectedPoint(Point point) {
		// TODO Auto-generated method stub
		if (point == endpointA) {
            return endpointC;
        } else if (point == endpointB) {
            return endpointA;
        } else if (point == endpointC) {
            return endpointA;
        } else {
            return null;
        }
		
		   
		
	}

	@Override
	public void trainEnteredCrossing() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void trainExitedCrossing() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public int getNumPaths() {
		// TODO Auto-generated method stub
		return 0;
	}
	
}
